#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//////////////////////////////////////////////////////////////////
/////////////////////////// STRUKTÚRÁK ///////////////////////////
//////////////////////////////////////////////////////////////////

typedef struct termekek { // termekek struktúra deklaráció
    char nev[150];
    double ar;
    struct termekek *next; // következő termék elem fejére mutató pointer
} termekek, *termekek_ptr; // typedef -fel elnevezzük és pointert is csinálunk belőle

typedef struct vasarlasok { // vásárlások struktúra deklaráció
    double sum_price;
    struct vasarlasok *next; // következő vásárás elem fejére mutató pointer
    struct termekek *termek_lista; // termék lista fejére mutató pointer
} vasarlasok, *vasarlasok_ptr;

//////////////////////////////////////////////////////////////////
//////////////////////// LISTA FÜGGVÉNYEK ////////////////////////
//////////////////////////////////////////////////////////////////
// kell mellé egy aránylag rövid tömör leírás

termekek_ptr push_product(termekek_ptr head, char nev[150], double ar) { // paraméterek
    termekek_ptr tp = malloc(sizeof(termekek)); // memória hely foglalás és annak címének átadása a pointernek
    if (tp == NULL) { // ha nem tud memóriát foglalni hibát ad és kilép
        printf("Couldn\'t allocate memory for new list item\n");
        return 0;
    }
    strcpy(tp->nev, nev); // az új lista elemnek oda adjuk a termék nevét
    tp->ar = ar; // és az árat
    tp->next = head; // az eddigi lista fejét utánna láncoljuk az új elemnek
    head = tp; // a lista utolsó elemének fejének címévé tesszük az új elemet
    return head; // vissza adjuk az új kezdőcímet tp=>head
}
// kell mellé egy aránylag rövid tömör leírás

vasarlasok_ptr push_purchase(vasarlasok_ptr head, termekek_ptr termek_p) { // fejléc
    vasarlasok_ptr vp = malloc(sizeof(vasarlasok)); // memória hely foglalás és annak címének átadása a pointernek
    if (vp == NULL) { // ha nem tud memóriát foglalni hibát ad és kilép
        printf("Couldn\'t allocate memory for new list item\n");
        return 0;
    }
    vp->next = head; // az eddigi lista fejét utánna láncoljuk az új elemnek
    vp->termek_lista = termek_p; // a már elkészített termékek listát hozzáfűzzük a listához
    head = vp; // a lista utolsó elemének fejének címévé tesszük az új elemet
    return head; // vissza adjuk az új kezdőcímet vp=>head
}
// kell mellé egy aránylag rövid tömör leírás

void delete_products(termekek_ptr head) { // egy termék lista összes elemének törlése
    if (head != NULL) {
        while (head != NULL) { // amég nem érünk a lista végére
            termekek_ptr tmp = head->next; // a következő elem címét elmentjük egy ideiglenes termekek pointerbe
            free(head); // felszabadítjuk a verem tetején lévő elemet
            head = tmp; // megadjuk a verem új fej elemét
        }
    }
}
// kell mellé egy aránylag rövid tömör leírás

void delete_purchases(vasarlasok_ptr head) { // az összes vásárlások lista elem törlése az összes termék listával együtt
    if (head != NULL) {
        while (head != NULL) { // amég nem érünk a lista végére
            vasarlasok_ptr tmp = head->next; // a következő elem címét elmentjük egy ideiglenes termekek pointerbe
            delete_products(head->termek_lista); // a termek listát átadjuk a delete_products fgv -nek
            free(head); // felszabadítjuk a verem tetején lévő elemet
            head = tmp; // megadjuk a verem új fej elemét
        }
    }
}

//////////////////////////////////////////////////////////////////
/////////////////////////// ADATKEZELÉS //////////////////////////
//////////////////////////////////////////////////////////////////


// kell mellé egy aránylag rövid tömör leírás
void sum_price(vasarlasok_ptr head) { // a vásárlás lista fejének pointerét oda adjuk
    double sum = 0.0; // az épp summázott termék lista ideiglenes értékének tárolója
    for (vasarlasok_ptr v = head; v != NULL; v = v->next) { // a vásárlások lista bejárása
        for (termekek_ptr t = v->termek_lista; t != NULL; t = t->next) { // a termékek lista bejárása
            sum += t->ar; // az összes árat hozzá adjuk a sum ideiglenes változóhoz
        }
        v->sum_price = sum; // a summázott árra átálítjuk a sum_price változót a gerincben
        sum = 0.0;
    }
}

// kell mellé egy aránylag rövid tömör leírás

// az avg_price mindenképp a sum_price fgv után szabad csak meghívni
double avg_price(vasarlasok_ptr head) {
    double sum = 0, avg = 0.0; // alapértékek megadása a gyüjtő summának és az átlagnak
    int i = 0; //elemek darabszáma
    for (vasarlasok_ptr v = head; v != NULL; v = v->next) { // a vásárlások lista bejárása
        i++; // minden vasarlasok lista elemnél hozzá adunk egyet az elem számlálóhoz
        sum += v->sum_price; // hozzá adjuk a jelenlegi lista elemben tárolt sum_price értékét a sum -hoz
    }
    //printf("sum:%0.2f \ni:%d\n", sum, i);
    avg = (sum/i);
    return avg; // vissza adja a kiszámolt átlag eladási árat
}
// kell mellé egy aránylag rövid tömör leírás

void closest_to_avg(vasarlasok_ptr head) {
    double curr_closest = 0;
    termekek_ptr out;
    vasarlasok_ptr value;
    double avg = avg_price(head);
    for (vasarlasok_ptr tmp = head; tmp != NULL; tmp = tmp->next) {
        if (avg < tmp->sum_price) { // ha az átlag értéke nagyobb mint az teljes kosárérték
            double r = fabs(tmp->sum_price - avg); // kivonjuk az átlagot a teljes értékből majd abszolútértéket vonunk
            if (curr_closest == 0) { // ha még nem volt megváltoztatva a legközelebbi érték
                curr_closest = r; // akkor ezt most megtesszük
                out = tmp->termek_lista; // elmentjük a termék listát
                value = tmp; // és a kosár értékét is ez mindenhol ugyan így néz ki
            } else if (curr_closest > r) { // ha az új érték kisebb mint a régi akkor az új átveszi a régi helyét
                curr_closest = r;
                out = tmp->termek_lista;
                value = tmp;
            }
        } else if (avg > tmp->sum_price) {
            double r = fabs(avg - tmp->sum_price);
            if (curr_closest == 0) { //
                curr_closest = r;
                out = tmp->termek_lista;
                value = tmp;
            } else if (curr_closest > r) {
                curr_closest = r;
                out = tmp->termek_lista;
                value = tmp;
            }
        }
    }
    printf("Az átlag kosárértékhez legközelebbi kosár értéke: %0.2f Ft, tartalma:\n", value->sum_price);
    for (out; out->next != NULL; out = out->next) { // kiírjuk a kosár tartalmát
        printf("Termék név: %s, \f\tár: %0.2f Ft\n", out->nev, out->ar);
    }
}

//////////////////////////////////////////////////////////////////
//////////////////////////// BEOLVASÁS ///////////////////////////
//////////////////////////////////////////////////////////////////

///******************/// FILEOK MEGNYITÁSA ///*****************///

// kell mellé egy aránylag rövid tömör leírás

vasarlasok_ptr file_to_list(vasarlasok_ptr head, char purchase_file[], char product_file[]) {
    FILE *purchase_p = fopen(purchase_file, "r"); // megnyitjuk a vásárlások filet szöveges olvasás módban
    if (purchase_p == NULL) { // ha nem sikerül megnyitni a filet akkor hibaüzenetet adunk és kilépünk
        printf("Couldn\'t open purchases file\n");
        return 0;
    }

    FILE *product_p = fopen(product_file, "r"); // megnyitjuk a termékek filet szöveges olvasás módban
    if (product_p == NULL) { // ha nem sikerül megnyitni a filet akkor hibaüzenetet adunk és kilépünk
        printf("Couldn\'t open products file\n");
        return 0;
    }

//////////////////////////////////////////////////////////////////

    int tmp_id, eq; // ideiglenes változók deklarálása
    double tmp_ar;
    char tmp_nev[150];
    char tmp_line[1000], split[] = " "; // változó deklaráció
    while (fgets(tmp_line, sizeof(tmp_line), purchase_p) != EOF) { // sorról sorra olvasunk a file végéig
        termekek_ptr product_list = malloc(sizeof(termekek)); // új termék lista kezdő elem
        product_list->next = NULL; // beállítjuk a lista végének
        char *char_int = strtok(tmp_line, split); // egy új pointerbe leválasztjuk a string első elemét
        eq = strcmp(char_int, "n\n"); // megnézzük hogy a sor végére értünk e
        while (char_int != NULL && eq != 0) { // addig megyünk a stringen keresztül amég nem találkozunk a lezáró n karakterrel
            while (fscanf(product_p, "%d %lf %[^Nv\n]%*c", &tmp_id, &tmp_ar, tmp_nev) != EOF) { // végig megyünk a termékek fileon
                if (tmp_id == atoi(char_int)) { // ha a termék id egyezik az eladások file épp olvasott sorában vizsgált id -val
                    product_list = push_product(product_list, tmp_nev, tmp_ar); // ha van egyezzés az id -k között akkor az berakjuk a listába
                    break; // azért hogy ne menjen tovább értelmetlenül a ciklus ha már találtunk egyezést kilépünk, ha nincs egyezés akkor nem csinálunk semmit
                }
            }
            char_int = strtok(NULL, split); // a split változóban megadott szóközös pontokon szétválasztjuk a stringet
            if (char_int == NULL) // ha a vásárlások file legvégére értünk akkor kilépünk a ciklusból
                break;
            else
                eq = strcmp(char_int, "n\n"); // megnézzük hogy a sor végére értünk e
            rewind(product_p); // a termékek file elejére megyünk
        }
    if (char_int == NULL) // ha a vásárlások file legvégére értünk akkor kilépünk a ciklusból
        break;
    head = push_purchase(head, product_list); // ha n karakterrel találkozik a while kilép és a termék lista bekerül a vásárlás gerincbe
    }
    fclose(purchase_p); // bezárjuk a vásárlások filet
    fclose(product_p); // bezárjuk a termékek filet
    return head;
}

//////////////////////////////////////////////////////////////////
/////////////////////////// FŐ PROGRAM ///////////////////////////
//////////////////////////////////////////////////////////////////

// kell mellé egy aránylag rövid tömör leírás

int main(void) {
    vasarlasok_ptr vp = calloc(1, sizeof(vasarlasok)); // egy vp nevű vasarlasok típusú pointer címére foglalunk helyet az első lista elemnek
    if (vp == NULL) { // ha nem sikerül memóriát foglalni akkor hibaüzenetet adunk és kilépünk
        printf("Couldn\'t allocate memory for purchases\n");
        return 0;
    }
    vp->next = NULL; // NULL pointerrel beállítjuk a lista végét
    vp = file_to_list(vp, "vasarlasok.txt", "termekek.txt");

    sum_price(vp);
    printf("A kosarak átlag ára %0.2f Ft\n\n", avg_price(vp));
    closest_to_avg(vp);

    delete_purchases(vp); // memória felszabadítása

    return 0;
}
